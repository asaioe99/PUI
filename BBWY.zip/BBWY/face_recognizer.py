import os
import sys
import glob
from winsound import PlaySound
from cv2 import CAP_PROP_FPS, CAP_PROP_FRAME_WIDTH
import numpy as np
import time
import cv2
from winsound import PlaySound, SND_PURGE, SND_ASYNC

COSINE_THRESHOLD = 0.363
NORML2_THRESHOLD = 1.128

# 特徴を辞書と比較してマッチしたユーザーとスコアを返す関数
def match(recognizer, feature1, dictionary):
    for element in dictionary:
        user_id, feature2 = element
        score = recognizer.match(feature1, feature2, cv2.FaceRecognizerSF_FR_COSINE)
        if score > COSINE_THRESHOLD:
            return True, (user_id, score)
    return False, ("", score)

def main():
    # キャプチャを開く
    directory = os.path.dirname(__file__)
    if len(sys.argv) < 2:
        print("error 0")
        exit()

    if sys.argv[1] == 'pic':
        capture = cv2.VideoCapture(os.path.join(directory, sys.argv[2])) # 画像ファイル
    elif sys.argv[1] == 'mov':
        capture = cv2.VideoCapture(os.path.join(directory, sys.argv[2])) # 動画ファイル
    elif sys.argv[1] == 'cam':
        capture = cv2.VideoCapture(0) # カメラ
        capture.set(cv2.CAP_PROP_FOURCC, cv2.VideoWriter_fourcc('M', 'J', 'P', 'G'))
        capture.set(cv2.CAP_PROP_FRAME_WIDTH, 1080)
        capture.set(cv2.CAP_PROP_FRAME_WIDTH, 1920)
        capture.set(cv2.CAP_PROP_FPS, 30)
    else:
        print("error 1")
        exit()        

    if not capture.isOpened():
        print("any images do not exist")
        exit()

    # 特徴を読み込む
    dictionary = []
    files = glob.glob(os.path.join(directory + '\\face_find\\', "*.npy"))
    for file in files:
        feature = np.load(file)
        user_id = os.path.splitext(os.path.basename(file))[0]
        dictionary.append((user_id, feature))

    # モデルを読み込む
    weights = os.path.join(directory + '\\model\\', "yunet.onnx")
    face_detector = cv2.FaceDetectorYN_create(weights, "", (0, 0))
    weights = os.path.join(directory + '\\model\\', "face_recognizer_fast.onnx")
    face_recognizer = cv2.FaceRecognizerSF_create(weights, "")


    ut = time.time()
    while True:
        # フレームをキャプチャして画像を読み込む
        result, image = capture.read()
        if result is False:
            cv2.waitKey(0)
            break

        # 画像が3チャンネル以外の場合は3チャンネルに変換する
        channels = 1 if len(image.shape) == 2 else image.shape[2]
        if channels == 1:
            image = cv2.cvtColor(image, cv2.COLOR_GRAY2BGR)
        if channels == 4:
            image = cv2.cvtColor(image, cv2.COLOR_BGRA2BGR)

        # 入力サイズを指定する
        height, width, _ = image.shape
        face_detector.setInputSize((width, height))

        # 顔を検出する
        result, faces = face_detector.detect(image)
        faces = faces if faces is not None else []

        for face in faces:
            # 顔を切り抜き特徴を抽出する
            aligned_face = face_recognizer.alignCrop(image, face)
            feature = face_recognizer.feature(aligned_face)

            # 辞書とマッチングする
            result, user = match(face_recognizer, feature, dictionary)

            # 顔のバウンディングボックスを描画する
            box = list(map(int, face[:4]))
            color = (0, 255, 0) if result else (0, 0, 255)
            thickness = 1
            cv2.rectangle(image, box, color, thickness, cv2.LINE_AA)

            # 認識の結果を描画する
            id, score = user if result else ("unknown", user[1])
            text = "{0} ({1:.2f})".format(id, score)
            position = (box[0], box[1] - 10)
            font = cv2.FONT_HERSHEY_SIMPLEX
            scale = 0.5
            cv2.putText(image, text, position, font, scale, color, thickness, cv2.LINE_AA)

            if id != 'unknown' and time.time() - ut > 3:
                PlaySound('sound\\detect.wav', SND_ASYNC)
                ut = time.time()

        # 画像を表示する
        cv2.imshow("face recognition", image)
        key = cv2.waitKey(1)
        if key == ord('q'):
            break
    
    cv2.destroyAllWindows()

if __name__ == '__main__':
    main()