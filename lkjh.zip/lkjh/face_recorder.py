# coding: UTF-8
import os
import sys
import glob
import pafy
from cv2 import CAP_PROP_FPS, CAP_PROP_FRAME_WIDTH
import numpy as np
import time
import datetime
import cv2
from winsound import PlaySound, SND_PURGE, SND_ASYNC

COSINE_THRESHOLD = 0.363
NORML2_THRESHOLD = 1.128

# 登録したデータの中から次の一連番号を取得
def get_next_ID(directory):
    max = 0
    directory += '\\face_record\\'
    files = glob.glob(os.path.join(directory, "*.npy"))
    if files is None:
        return 0
    for file in files:
        user_id = os.path.splitext(os.path.basename(file))[0]
        t = int(user_id.split('_')[1])
        if t > max:
            max = t
    return max + 1

# 特徴を辞書と比較してマッチしたユーザーとスコアを返す関数
def match(recognizer, feature1, dictionary):
    for element in dictionary:
        user_id, feature2 = element
        score = recognizer.match(feature1, feature2, cv2.FaceRecognizerSF_FR_COSINE)
        if score > COSINE_THRESHOLD:
            return True, (user_id, score)
    return False, ("", 0.0)

def make_dictionary(dictionary, directory):
    directory1 = directory + '\\face_record\\'
    directory2 = directory + '\\model\\'

    files = glob.glob(os.path.join(directory1, "*.npy"))
    for file in files:
        feature = np.load(file)
        user_id = os.path.splitext(os.path.basename(file))[0]
        dictionary.append((user_id, feature))
        print('loading face data:' + user_id)

    # モデルを読み込む
    weights = os.path.join(directory2, "yunet.onnx")
    face_detector = cv2.FaceDetectorYN_create(weights, "", (0, 0))
    weights = os.path.join(directory2, "face_recognizer_fast.onnx")
    face_recognizer = cv2.FaceRecognizerSF_create(weights, "")

    return face_detector, face_recognizer

def add_dictionary(dictionary, newID):
    feature = np.load(newID)
    user_id = os.path.split(os.path.basename(newID))[0]
    dictionary.append((user_id, feature))

def main():
    # キャプチャを開く
    directory = os.path.dirname(__file__)
    if len(sys.argv) < 2:
        print("error")
        exit()
    if sys.argv[1] == 'mov':
        capture = cv2.VideoCapture(os.path.join(directory, sys.argv[2])) # 画像ファイル
    elif sys.argv[1] == 'youtube':
        url = sys.argv[2]
        #ydl_opts = {"--no-check-certificate": True}
        video = pafy.new(url)#, ydl_opts)
        best = video.getbest(preftype="mp4")
        capture = cv2.VideoCapture(best.url)
    elif sys.argv[1] == 'cam':
        capture = cv2.VideoCapture(0) # カメラ
        capture.set(cv2.CAP_PROP_FOURCC, cv2.VideoWriter_fourcc('M', 'J', 'P', 'G'))
        capture.set(cv2.CAP_PROP_FRAME_WIDTH, 1080)
        capture.set(cv2.CAP_PROP_FRAME_WIDTH, 1920)
        capture.set(cv2.CAP_PROP_FPS, 30)
    else:
        print("error")
        exit()        

    if not capture.isOpened():
        print("any images do not exist")
        exit()

    # 特徴を読み込む
    dictionary = []
    face_detector, face_recognizer = make_dictionary(dictionary, directory)

    # 時刻情報取得
    ut = time.time()

    # 一連番号
    num = get_next_ID(directory)

    while True:
        # フレームをキャプチャして画像を読み込む
        result, image = capture.read()
        if result is False:
            cv2.waitKey(0)
            break

        # 画像が3チャンネル以外の場合は3チャンネルに変換する
        channels = 1 if len(image.shape) == 2 else image.shape[2]
        if channels == 1:
            image = cv2.cvtColor(image, cv2.COLOR_GRAY2BGR)
        if channels == 4:
            image = cv2.cvtColor(image, cv2.COLOR_BGRA2BGR)

        # 入力サイズを指定する
        height, width, _ = image.shape
        face_detector.setInputSize((width, height))

        # 顔を検出する
        result, faces = face_detector.detect(image)
        faces = faces if faces is not None else []

        for face in faces:
            # 顔認識サイズが一定面積未満なら処理せず
            box = list(map(int, face[:4]))
            if box[2] * box[3] < 1600:
                continue

            # 顔を切り抜き特徴を抽出する
            aligned_face = face_recognizer.alignCrop(image, face)
            feature = face_recognizer.feature(aligned_face)

            # 辞書とマッチングする
            result, user = match(face_recognizer, feature, dictionary)

            if result:
                # 顔のバウンディングボックスを描画する
                color = (0, 255, 0) if result else (0, 0, 255)
                thickness = 2
                cv2.rectangle(image, box, color, thickness, cv2.LINE_AA)

                # 認識の結果を描画する
                id, score = user
                text = "{0} ({1:.2f})".format(id, score)
                position = (box[0], box[1] - 10)
                font = cv2.FONT_HERSHEY_SIMPLEX
                scale = 0.6
                cv2.putText(image, text, position, font, scale, color, thickness, cv2.LINE_AA)

                print(str(datetime.datetime.now()) + ' : detect ' + id)

            else:
                # 顔情報の追加更新
                tmp = directory + '\\face_record\\ID_' + f'{num:04}' + '.npy'
                np.save(tmp, feature)
                add_dictionary(dictionary, tmp)
                print(str(datetime.datetime.now()) + ' : add  ' + 'ID_' + f'{num:04}')

                cv2.imwrite(directory + '\\face_img_record\\ID_' + f'{num:04}.jpg', aligned_face)

                num = num + 1
                if time.time() - ut > 3:
                    PlaySound('sound\\record.wav', SND_ASYNC)
                    ut = time.time()

        # 画像を表示する
        cv2.namedWindow("face recognition", cv2.WINDOW_NORMAL)
        cv2.imshow("face recognition", image)
        key = cv2.waitKey(1)
        if key == ord('q'):
            break
    
    cv2.destroyAllWindows()

if __name__ == '__main__':
    main()